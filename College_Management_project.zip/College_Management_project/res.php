<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<?php
     mysql_connect('localhost:3307','root','');
	 mysql_select_db("anjali") or die (mysql_error());
?>
</head>
<?php
      if(isset($_POST['insert']))
	  {
	    $nm=$_POST['abc1'];
		$fn=$_POST['abc2'];
		$mn=$_POST['abc3'];
		$add=$_POST['abc4'];
		$mb=$_POST['abc5'];
		$ei=$_POST['abc6'];
		$dob=$_POST['dt'];
		if($_POST['a4']=="gen")
		$ct="gen";
		else
		if($_POST['a4']=="obc")
		$ct="obc";
		else
		if($_POST['a4']=="sc")
		$ct="sc";
		else
		 if($_POST['a4']=="st")
		 $ct="st";
		$ar=$_POST['abc9'];
		$cc=$_POST['abc10'];
		$ic=$_POST['abc11'];
		$rc=$_POST['abc12'];
		$cn=$_POST['abc13'];
		$ca=$_POST['abc14'];
		$ac=$_POST['abc15'];
		if($_POST['gen']=="male")
		$gender="male";
		else
		  if($_POST['gen']=="female")
		  $gender="female";
		  if($_POST['cc']=="high school" && $_POST['cc0']=="intermediate" && $_POST['cc1']=="graduation" && $_POST['cc2']=="post graduation" && $_POST['cc3']=="other")
			$qul="high school,intermediate, graduation, post_graduation, other";
			else
			if($_POST['cc']=="high school" && $_POST['cc0']=="intermediate" && $_POST['cc1']=="graduation" && $_POST['cc2']=="post graduation")
		   $qul="high school, intermediate, graduation, post graduation";
		   else
		  if($_POST['cc']=="high school" && $_POST['cc0']=="intermediate" && $_POST['cc1']=="graduation")
		  $qul="high_school, intermedite, graduation";
		  else
		  if($_POST['cc']=="high school"&& $_POST['cc0']=="intermediate")
		$qul="high school,intermediate";
		else
		  if($_POST['cc']=="high school")
		  $qul="high school";
		    
		$qd=$_POST['abc18'];
	        mysql_query("insert into web values('$nm','$fn','$mn','$add','$mb','$ei','$dob','$ct','$ar','$cc','$ic','$rc','$cn','$ca','$ac','$gender','$qul','$qd')") or die(mysql_error());
			echo"<script> alert('Date Inserted Succesfull..!')</script>";
	}
      ?>
<body text="#000033"><CENTER><h1>WEBSTONE COLLEGE</h1></br></br></CENTER>
<form action="" method="post">
<table border="1"align="center"width="700" cellpadding="10" cellspacing="10" bgcolor="#CCCCCC"; bordercolor="#000066";>
<TR><TH COLSPAN="2"><H1>ADMISSIONS FORM</H1></TH></TR>
<TR><TH><strong>NAME</strong></TH><td><input name="abc1" type="text" class="form-control" placeholder="ENTER YOUR NAME"/ style="height:40PX; width:370px;"></BR></td></tr>
<tr><th><strong>FATHER'S NAME</strong></th><td><input name="abc2" type="text" class="form-control" placeholder="ENTER YOUR FATHER'S NAME"/ style="height:40px;  width:370px;"><br /></td></tr>
<tr><th><strong>MATHER'S NAME</strong></th><td><input name="abc3" type="text" class="form-control" placeholder="ENTER YOUR MOTHER'S NAME"/ style="height:40PX; width:370PX;"><BR /></td></tr>
<TR><th><strong>ADDRESS</strong></th><td><input name="abc4" type="text" class="form-control"/ style="height:40PX; width:370px;"></BR></td></tr>
<tr><th><strong>MOBILE NO</strong></th><td><input name="abc5" type="text" class="form-control"/ style="height:40PX; width:370px;"></BR></td></tr>
<tr><th>
<strong>EMAIL-ID</strong></th><td><input name="abc6" type="text" class="form-control"/ style="height:40PX; width:370px;"></BR></td></tr>
<tr><th><strong>DATE OF BIRTH</strong></th><td><input type="date" name="dt" min="15-01-1980" max="20-01-2000" /><br /></td></tr>
<tr><th><strong>CASTE</strong></th><td><input type="radio" name="a4" value="gen">GEN

<input type="radio" name="a4" value="obc">OBC

<input type="radio" name="a4" value="sc">SC

<input type="radio" name="a4" value="st">ST</BR></td></tr>
<tr><th><strong>AADHAR NO</strong></th><td><input name="abc9" type="text" class="form-control" placeholder="AADHAR NO"/ style="height:40PX; width:370px;"></BR></td></tr>
<tr><th><strong>CASTE CRATIFICATE</strong></th><td><input name="abc10" type="text" class="form-control" placeholder="SERIAL NO."/ style="height:40PX; width:370px;"></BR></td></tr>
<tr><th><strong>INCOME CRATIFICATE</strong></th><td><input name="abc11" type="text" class="form-control" placeholder="SERIAL NO"/ style="height:40PX; width:370px;"></BR></td></tr>
<tr><th><strong>RESIDENCE CRATIFICATE</strong></th><td><input name="abc12" type="text" class="form-control" placeholder="SERIAL NO"/ style="height:40PX; width:370px;"></BR></td></tr>
<tr><th><strong>COLLEGE NAME</strong></th><td><input name="abc13" type="text" class="form-control"/ style="height:40PX; width:370px;"></BR></td></tr>
<tr><th><strong>COLLEGE ADDRESS</strong></th><td><input name="abc14" type="text" class="form-control"/ style="height:40px;  width:370px;"><br /></td></tr>
<tr><th><strong>ACADEMICS</strong></th><td><SELECT NAME="abc15"><OPTION>ART FACULTY</OPTION><OPTION>SCIENCE FACULTY</OPTION>
<OPTION>B.SC.-INFORMATION TECHNOLOGY</OPTION><OPTION>DIPLOMA COURSES</OPTION></SELECT>
</BR></td></tr>
<tr><th><strong>GENDER</strong></th><td><input name="gen" TYPE="RADIO" value="male" class="form-control">MALE<input name="gen"TYPE="RADIO" value="female" class="form-control">FEMALE</BR></td></tr>
<tr><th><strong>QUALIFICATION</strong></th><td>
<input type="checkbox" name="cc" value="high school">HIGH SCHOOL
<input type="checkbox" name="cc0" value="intermediate">INTERMEDIATE
<input type="checkbox" name="cc1" value="graduation">GRADUATION
<input type="checkbox" name="cc2" value="post graduation">POST GRADUATION
<input type="checkbox" name="cc3" value="other">OTHER</BR></td></tr>
<tr><th><strong>QUALIFICATION DETAIL WITH PRECENTAGE AND OTHER</strong></th><td><input name="abc18" type="text" class="form-control"/ style="height:40PX; width:370px;"></BR></td></tr>
<TR><TH colspan="2">
<button name="insert" class="btn btn-success" type="submit">SUBMIT</button>
<button name="insert" class="btn btn-success" type="reset">RESET</button></TH></TR>  
</form></CENTER></table></body>
</html>