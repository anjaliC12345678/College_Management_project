-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2019 at 04:26 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `anjali`
--

-- --------------------------------------------------------

--
-- Table structure for table `web`
--

CREATE TABLE IF NOT EXISTS `web` (
  `name` text NOT NULL,
  `father name` text NOT NULL,
  `mother's name` text NOT NULL,
  `address` varchar(150) NOT NULL,
  `mobile no` int(15) NOT NULL,
  `e-mail id` varchar(150) NOT NULL,
  `date of birth` date NOT NULL,
  `caste` varchar(50) NOT NULL,
  `aadhar no` int(50) NOT NULL,
  `caste certificate` int(50) NOT NULL,
  `income certificate` int(50) NOT NULL,
  `residence certificate` int(50) NOT NULL,
  `college name` varchar(50) NOT NULL,
  `college address` varchar(150) NOT NULL,
  `academics` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `qualification detail with precentage and other` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `web`
--

INSERT INTO `web` (`name`, `father name`, `mother's name`, `address`, `mobile no`, `e-mail id`, `date of birth`, `caste`, `aadhar no`, `caste certificate`, `income certificate`, `residence certificate`, `college name`, `college address`, `academics`, `gender`, `qualification`, `qualification detail with precentage and other`) VALUES
('anjali hgttkg', 'suresh', 'chanda', 'ahgtcflgidwe9o', 647613, 'csdgguifsdjosdl', '2019-08-19', 'on', 457239367, 2147483647, 2147483647, 2147483647, 'gvsddgefbhieifbihl', 'ytdwfvfuewuieopweecjo', 'ART FACULTY', 'male', 'on', 'kctewbv8guebjhi'),
('anjali hgttkg', 'suresh', 'chanda', 'ahgtcflgidwe9o', 647613, 'csdgguifsdjosdl', '2019-08-19', 'on', 457239367, 2147483647, 2147483647, 2147483647, 'gvsddgefbhieifbihl', 'ytdwfvfuewuieopweecjo', 'ART FACULTY', 'male', 'on', 'kctewbv8guebjhi'),
('anjali hgttkg', 'suresh', 'chanda', 'ahgtcflgidwe9o', 647613, 'csdgguifsdjosdl', '2019-08-19', 'on', 457239367, 2147483647, 2147483647, 2147483647, 'gvsddgefbhieifbihl', 'ytdwfvfuewuieopweecjo', 'ART FACULTY', 'male', 'on', 'kctewbv8guebjhi'),
('gvseuilwereol;nc', 'suresh', 'chanda', 'ahgtcflgidwe9o', 647613, 'csdgguifsdjosdl', '2019-08-19', 'on', 457239367, 2147483647, 2147483647, 2147483647, 'gvsddgefbhieifbihl', 'ytdwfvfuewuieopweecjo', 'ART FACULTY', 'female', 'on', 'kctewbv8guebjhi'),
('gvseuilwereol;nc', 'suresh', 'chanda', 'ahgtcflgidwe9o', 647613, 'csdgguifsdjosdl', '2019-06-12', 'on', 457239367, 2147483647, 2147483647, 2147483647, 'gvsddgefbhieifbihl', 'ytdwfvfuewuieopweecjo', 'ART FACULTY', 'female', 'on', 'kctewbv8guebjhi'),
('', '', '', '', 0, '', '0000-00-00', '', 0, 0, 0, 0, '', '', 'ART FACULTY', 'male', '', ''),
('', '', '', '', 0, '', '0000-00-00', 'on', 0, 0, 0, 0, '', '', 'ART FACULTY', 'male', 'on', ''),
('', '', '', '', 0, '', '0000-00-00', '', 0, 0, 0, 0, '', '', 'ART FACULTY', 'male', 'on', ''),
('', '', '', '', 0, '', '0000-00-00', 'gen', 0, 0, 0, 0, '', '', 'SCIENCE FACULTY', 'male', 'on', ''),
('', '', '', '', 0, '', '0000-00-00', 'gen', 0, 0, 0, 0, '', '', 'SCIENCE FACULTY', 'male', 'on', ''),
('', '', '', '', 0, '', '0000-00-00', 'obc', 0, 0, 0, 0, '', '', 'ART FACULTY', 'male', 'on', ''),
('', '', '', '', 0, '', '0000-00-00', 'sc', 0, 0, 0, 0, '', '', 'SCIENCE FACULTY', 'male', '', ''),
('', '', '', '', 0, '', '0000-00-00', 'sc', 0, 0, 0, 0, '', '', 'SCIENCE FACULTY', 'male', '', ''),
('', '', '', '', 0, '', '0000-00-00', 'obc', 0, 0, 0, 0, '', '', 'SCIENCE FACULTY', 'female', '', ''),
('', '', '', '', 0, '', '0000-00-00', 'obc', 0, 0, 0, 0, '', '', 'B.SC.-INFORMATION TECHNOLOGY', 'female', '', ''),
('', '', '', '', 0, '', '0000-00-00', 'obc', 0, 0, 0, 0, '', '', 'B.SC.-INFORMATION TECHNOLOGY', 'female', '', ''),
('', '', '', '', 0, '', '0000-00-00', 'obc', 0, 0, 0, 0, '', '', 'ART FACULTY', 'female', 'high school', ''),
('anjali', 'suresh', 'chanda', 'tarang chowk', 4363, 'hdjjotwjgnkjvn po44', '2019-09-10', 'obc', 87350, 2147483647, 2147483647, 2147483647, 'hterghtoihnjuribnerhj', 'yhhydnw3urc5co45', 'B.SC.-INFORMATION TECHNOLOGY', 'female', 'high school', 'vter784c045[o'),
('', '', '', '', 0, '', '0000-00-00', '', 0, 0, 0, 0, '', '', 'ART FACULTY', '', 'high school', ''),
('', '', '', '', 0, '', '0000-00-00', 'obc', 0, 0, 0, 0, '', '', 'B.SC.-INFORMATION TECHNOLOGY', 'female', '', ''),
('', '', '', '', 0, '', '0000-00-00', 'obc', 0, 0, 0, 0, '', '', 'B.SC.-INFORMATION TECHNOLOGY', 'female', '', ''),
('sunita', 'ramesh', 'suman', 'gkp', 2147483647, 'sunita@gmail.com', '1999-08-28', 'obc', 2147483647, 236541, 125478, 365241, 'abc', 'gorkhpur', 'ART FACULTY', 'female', 'high school,intermediate, graduation, post_graduat', 'dfdfddfkjlf jlfklf sdklfklf klfjkld');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
